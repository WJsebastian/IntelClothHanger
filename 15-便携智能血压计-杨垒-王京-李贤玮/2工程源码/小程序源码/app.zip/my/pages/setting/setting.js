// pages/setting/setting.js
const innerAudioContext = wx.createInnerAudioContext()
const bluetooth = require("../../utils/bluetooth")
innerAudioContext.autoplay = true
innerAudioContext.src = 'C:\college\junior(2)\智能电子系统设计与实践\"开始测量音效.mp3"'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },
  audio_test:function(){
    innerAudioContext.play();
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
  set_time:function(param){
    bluetooth.set_TIME('456789');
    /*
    wx.showModal({
      title: '提示',
      content: '重置时间完成',
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })*/
  }
})