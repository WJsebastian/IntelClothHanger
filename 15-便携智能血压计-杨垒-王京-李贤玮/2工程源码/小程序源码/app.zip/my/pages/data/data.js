var wxCharts = require('../../utils/wxcharts.js');
const util = require('../../utils/util.js')
const app = getApp();
var lineChart = null;
var startPos = null;
// 存储数据的方法
/*
var saveExprs1 = function(expr) {
  //获取存储数据的数组
  var exprs = wx.getStorageSync("measure_time") || []
  //向数组中添加新的元素
  exprs.unshift(expr)
  //将添加的元素存储到本地
  wx.setStorageSync("measure_time", exprs)
}
var saveExprs2 = function(expr) {
  var exprs = wx.getStorageSync("systolic") || []
  exprs.unshift(expr)
  wx.setStorageSync("systolic", exprs)
}
var saveExprs3 = function(expr) {
  var exprs = wx.getStorageSync("diastolic") || []
  exprs.unshift(expr)
  wx.setStorageSync("diastolic", exprs)
}*/

Page({
    data: {
      // key:'measure_time',
      // key:'systolic',
      // key:'diastolic'
    },
    touchHandler: function (e) {
        lineChart.scrollStart(e);
    },
    moveHandler: function (e) {
        lineChart.scroll(e);
    },
    touchEndHandler: function (e) {
        lineChart.scrollEnd(e);
        lineChart.showToolTip(e, {
            format: function (item, category) {
                return category + ' ' + item.name + ':' + item.data 
            }
        });        
    },

    onLoad: function (e) {
      /*
      */
      
      
      /*
      if(util.get_low_pressure()!='' && util.get_high_pressure()!=''){
        saveExprs1(util.formatTime(new Date()))
        saveExprs2(parseFloat(util.get_high_pressure()))
        saveExprs3(parseFloat(util.get_low_pressure()))
      }
      */


    },
    onShow: function(){
      var t1 = wx.getStorageSync('measure_time') || []
      var t2 = wx.getStorageSync('systolic') || []
      var t3 = wx.getStorageSync('diastolic') || []
      console.log(t1)
      console.log(t2)
      console.log(t3)
        var windowWidth = 320;
        try {
            var res = wx.getSystemInfoSync();
            windowWidth = res.windowWidth;
        } catch (e) {
            console.error('getSystemInfoSync failed!');
        }

        lineChart = new wxCharts({
            canvasId: 'lineCanvas',
            type: 'line',
            categories: [t1[0],t1[1],t1[2],t1[3],t1[4],t1[5],t1[6],t1[7],t1[8],t1[9],t1[10],t1[11],t1[12],t1[13]],
            animation: false,
            series: [{
                name: '收缩压',
                data: [t2[0],t2[1],t2[2],t2[3],t2[4],t2[5],t2[6],t2[7],t2[8],t2[9],t2[10],t2[11],t2[12],t2[13]],
                format: function (val, name) {
                  return parseFloat(val).toFixed(2);
                }
            },
            {
                name: '舒张压',
                data: [t3[0],t3[1],t3[2],t3[3],t3[4],t3[5],t3[6],t3[7],t3[8],t3[9],t3[10],t3[11],t3[12],t3[13]],
                format: function (val, name) {
                    return parseFloat(val).toFixed(2)
                }
            }
        ],
            xAxis: {
                disableGrid: false
            },
            yAxis: {
                title: '血压值mmHg',
                format: function (val) {
                  return parseFloat(val).toFixed(2)
                },
                min: 50,
                max:200
            },
            width: windowWidth,
            height: 500,
            dataLabel: true,
            dataPointShape: true,
            enableScroll: true,
            extra: {
                lineStyle: 'curve'
            }
        });
    },
    gotohistory:function(param){
      wx.navigateTo({
        url: '/pages/history/history',
        })
    }
});
/*
function initChart(canvas, width, height, dpr) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr // 像素
  });
  canvas.setChart(chart);

  var t1=wx.getStorageSync('measure_time')
  var t2=wx.getStorageSync('systolic')
  var t3=wx.getStorageSync('diastolic')

  var option = {
    title: {
      text: '过去14天内的历史数据',
      left: 'center'
    },
    legend: {
      data: ['收缩压', '舒张压'],
      top: 50,
      left: 'center',
      backgroundColor: 'red',
      z: 100
    },
    grid: {
      containLabel: true
    },
    tooltip: {
      show: true,
      trigger: 'axis'
    },
    dataZoom:[
      {
        type:'inside',
        show:true,
        xAxisIndex:[0],
        start:0,
        end:50
      }
    ],
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: [t1[0],t1[1],t1[2],t1[3],t1[4],t1[5],t1[6],t1[7],t1[8],t1[9],t1[10],t1[11],t1[12],t1[13]]
      // show: false
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      }
      // show: false
    },
    series: [{
      name: '收缩压',
      type: 'line',
      smooth: true,
      data: [t2[0],t2[1],t2[2],t2[3],t2[4],t2[5],t2[6],t2[7],t2[8],t2[9],t2[10],t2[11],t2[12],t2[13]]
    }, {
      name: '舒张压',
      type: 'line',
      smooth: true,
      data: [t3[0],t3[1],t3[2],t3[3],t3[4],t3[5],t3[6],t3[7],t3[8],t3[9],t3[10],t3[11],t3[12],t3[13]]
    }]
  };
  chart.setOption(option);
  return chart;
}

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/bgi/bgi',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
      onInit: initChart
    }
  },

  onLoad: function (options) {
    
  },

  onReady: function () {

  },

  onShow: function () {

  },
  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {

  },

  onReachBottom: function () {

  },

  onShareAppMessage: function () {

  },
  gotohistory:function(param){
    wx.navigateTo({
      url: '/pages/history/history',
      })
  }
})*/
