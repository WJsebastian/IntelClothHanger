// pages/history/history.js.js
/*
const app = getApp()
// 存储数据的方法
var saveExprs1 = function(expr) {
  //获取存储数据的数组
  var exprs = wx.getStorageSync("measure_time") || []
  //向数组中添加新的元素
  exprs.unshift(expr)
  //将添加的元素存储到本地
  wx.setStorageSync("measure_time", exprs)
}
var saveExprs2 = function(expr) {
  //获取存储数据的数组
  var exprs = wx.getStorageSync("systolic") || []
  //向数组中添加新的元素
  exprs.unshift(expr)
  //将添加的元素存储到本地
  wx.setStorageSync("systolic", exprs)
}
var saveExprs3 = function(expr) {
  //获取存储数据的数组
  var exprs = wx.getStorageSync("diastolic") || []
  //向数组中添加新的元素
  exprs.unshift(expr)
  //将添加的元素存储到本地
  wx.setStorageSync("diastolic", exprs)
}*/

Page({
  /**
   * 页面的初始数据
   */
  data: {
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var a = wx.getStorageSync('measure_time') || []
    var b = wx.getStorageSync('systolic') || []
    var c = wx.getStorageSync('diastolic') || []

    this.setData({
    arry_data1: a,
    arry_data2: b,
    arry_data3: c
  })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
