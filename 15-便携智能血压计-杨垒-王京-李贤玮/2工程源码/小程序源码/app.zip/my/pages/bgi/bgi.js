const bluetooth = require("../../utils/bluetooth")
const util = require('../../utils/util.js')
// pages/bgi/bgi.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.clearStorage({
      success: (res) => {},
    })
      util.saveExprs1('5/1')
      util.saveExprs1('5/2')
      util.saveExprs1('5/3')
      util.saveExprs1('5/4')
      util.saveExprs1('5/5')
      util.saveExprs1('5/6')
      util.saveExprs1('5/7')
      util.saveExprs1('5/8')
      util.saveExprs1('5/9')
      util.saveExprs1('5/10')
      util.saveExprs1('5/11')
      util.saveExprs1('5/12')
      util.saveExprs1('5/13')
      util.saveExprs1('5/14')
  
      util.saveExprs2(120)
      util.saveExprs2(130)
      util.saveExprs2(125)
      util.saveExprs2(138)
      util.saveExprs2(127)
      util.saveExprs2(145)
      util.saveExprs2(120)
      util.saveExprs2(120)
      util.saveExprs2(130)
      util.saveExprs2(125)
      util.saveExprs2(138)
      util.saveExprs2(127)
      util.saveExprs2(145)
      util.saveExprs2(120)
  
      util.saveExprs3(80)
      util.saveExprs3(83)
      util.saveExprs3(78)
      util.saveExprs3(90)
      util.saveExprs3(80)
      util.saveExprs3(75)
      util.saveExprs3(88)
      util.saveExprs3(70)
      util.saveExprs3(80)
      util.saveExprs3(83)
      util.saveExprs3(78)
      util.saveExprs3(90)
      util.saveExprs3(80)
      util.saveExprs3(75)
      util.saveExprs3(88)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  measuring:function(param){
    
    wx.navigateTo({
      //url: '/pages/result/result',
      url: '/pages/measure_ing/measure_ing',
      })
  },
  connect:function(param){
      // wx.navigateTo({
      //   url: './BLElist/BLElist',
      // })
      //const bluetooth = require("../../utils/bluetooth")
      //bluetooth.bluetooth
      //('B0E12961-E717-C1DC-8C17-0115B2B9F6CA')//连接蓝牙
      bluetooth.bluetooth('B0E12961-E717-C1DC-8C17-0115B2B9F6CA')
    },

})