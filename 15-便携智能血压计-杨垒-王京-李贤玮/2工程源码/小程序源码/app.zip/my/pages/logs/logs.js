// logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    logs: [],
    key1: 'measure_time',
    key2: 'systolic',
    key3: 'diastolic'
  },
  
  onLoad() {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(function(log) {
        return util.formatTime(new Date(log))
      })
    })
  }
})
