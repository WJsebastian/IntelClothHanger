const util = require('util.js')
const BluetoothDetail = {
  inputValue: '',//想要链接的蓝牙设备id
  deviceId: '',//设备ID
  services: '',//蓝牙设备的uuid
  notify: '',//支持notify的特征值
  write: '',//支持write的特征值
  returnValue:'',//返回的token
  returnValue2:''//开锁后的返回
}
var app=getApp();

//开启蓝牙调用，判断蓝牙是否打开
const bluetooth = inputValue =>{
    BluetoothDetail.inputValue = inputValue
    wx.openBluetoothAdapter({
      success:function(res){
        wx.showToast({
          title: '初始化成功',
          icon:'success',
          duration:800
        })
        findBlue();
      },
      fail:function(res){
        wx.showToast({
          title: '请开启蓝牙',
          icon:'fails',
          duration:1000
        })
      }
    })
}
//2.搜索附近蓝牙设备
const findBlue = () =>{
  wx.startBluetoothDevicesDiscovery({
    allowDuplicatesKey:false,
    interval:0,
    success:function(res){
      wx.showLoading({
        title: '正在搜索设备',
      })
      getBlue();
    }
  })
}
//3.获取蓝牙设备信息
const getBlue = () => {
  console.log('getBlue ...')
  wx.getBluetoothDevices({
    success: (result) => {
      wx.hideLoading({
        success: (res) => {},
      })
      if(result.devices.length > 0){
        
        for(var i=0;i<result.devices.length;++i){
          console.log(result.devices[i])
          if(result.devices[i].deviceId == BluetoothDetail.inputValue || result.devices[i].localName == BluetoothDetail.inputValue){
            BluetoothDetail.deviceId = result.devices[i].deviceId
            connectBlue()
            break
          }
          if(result.devices.length - 1 == i){
            // console.log('WA1')
            findBlue()
          }
        }
      }else{
        
        findBlue()
      }
    },
    fail:function(){
      console.log('搜索蓝牙失败')
    }
  })
}
//4.通过蓝牙设备的id进行连接
const connectBlue = () =>{
  
  wx.createBLEConnection({
    deviceId: BluetoothDetail.deviceId,
    success:function(res){
      console.log('连接成功')
      wx.showToast({
        title: '连接成功',
        icon:'success',
        duration:800
      })
      wx.stopBluetoothDevicesDiscovery({
        success: (res) => {
          console.log('蓝牙连接成功！关闭蓝牙搜索...')
        },
      })
      getServiceID()
    },
    fail : function(err){
      console.log('error:'+err)
    }
  })
}
//5.获取服务的id
const getServiceID = ()=>{
  console.log('获取服务')
  wx.getBLEDeviceServices({
    deviceId: BluetoothDetail.deviceId,
    success:function(res){
      var index = 0;
      console.log('sow Services')
      for(var i = 0;i <res.services.length;++i){
        console.log(res.services[i])
      }
      var model = res.services[2]
      BluetoothDetail.services = model.uuid
      console.log('services : ' +BluetoothDetail.services)
      getCharacteID()
    }
  })
}
//6.获取蓝牙设备特性值
const getCharacteID = () => {
  console.log('获取蓝牙特性')
  console.log('设备Id：'+BluetoothDetail.deviceId)
  console.log('服务:' + BluetoothDetail.services)
  wx.getBLEDeviceCharacteristics({
    deviceId: BluetoothDetail.deviceId,
    serviceId: BluetoothDetail.services,
    success:function(res){
      console.log('成功获取')
      for(var i =0;i<res.characteristics.length;++i){
        
        var model = res.characteristics[i]
        console.log(model.properties)
        if(model.properties.notify&&model.properties.read&&model.properties.write){
          console.log('found suc')
          BluetoothDetail.notifyId = model.uuid
          BluetoothDetail.writeId = model.uuid
          console.log("notifyId: " + BluetoothDetail.notifyId)
          console.log("writeId: " + BluetoothDetail.writeId)
          startNotice(BluetoothDetail.notifyId)
        }
        
      }
    }
  })
}
//7.notify
const startNotice = uuid =>{
  wx.showToast({
    title: '测试蓝牙通信',
    icon:'loading',
    
  })
  console.log('开始发送')
  wx.notifyBLECharacteristicValueChange({
    characteristicId: uuid,
    deviceId: BluetoothDetail.deviceId,
    serviceId: BluetoothDetail.services,
    state: true,
    success:function(res){
      var str1 = '1234567890987654' //想写入的16进制的字符串
      console.log(str1)
      //var str2 = hexCharCodeToStr(str1)
      //console.log(str2)
      sendMy(string2buffer(str1))
    },
    fail(res) {
      wx.hideLoading({
        success: (res) => {},
      })
      wx.showToast({
        title: '蓝牙通信测试失败',
        icon:'fails',
        duration:1000
      })
      console.log(res, '启用低功耗蓝牙设备监听失败')
    }
  })
}
//8.写入蓝牙设备 内容获取token
const sendMy = buffer =>{
  console.log('写入！')
  wx.writeBLECharacteristicValue({
    characteristicId: BluetoothDetail.writeId,
    deviceId: BluetoothDetail.deviceId,
    serviceId: BluetoothDetail.services,
    value: buffer,
    success:function(res){
      console.log('写入成功！')
      wx.onBLECharacteristicValueChange((result) => {
        console.log('收到消息！')
        BluetoothDetail.returnValue = ab2hex(result.value)
        
        // result.value
        // ab2hex(result.value)
        
        console.log("returnValue:  "+BluetoothDetail.returnValue)
        
        var return_str = hex2str(BluetoothDetail.returnValue)
        console.log(return_str)
        var return_ascii= hexCharCodeToStr(return_str)
        console.log(return_ascii)
        if(return_str == '1234123412123456'){
          wx.hideLoading({
            success : (res)=>{}
          })
          wx.showToast({
            title: '测试成功',
            icon:'success',
            duration:800
          })
        }
        // var param = {
        //   str : BluetoothDetail.returnValue
        // }
        
      })
    },
    fail:function(){
      console.log('写入失败')
    }
  })
}
//9.

const hexCharCodeToStr = (hexCharCodeStr) => {
  var trimedStr = hexCharCodeStr.trim();
  var rawStr = trimedStr.substr(0, 2).toLowerCase() === "0x" ? trimedStr.substr(2) : trimedStr;
  var len = rawStr.length;
  if (len % 2 !== 0) {
      console.log("存在非法字符!");
      return "";
  }
  var curCharCode;
  var resultStr = [];
  for (var i = 0; i < len; i = i + 2) {
      curCharCode = parseInt(rawStr.substr(i, 2), 16);
      resultStr.push(String.fromCharCode(curCharCode));
  }
  console.log('转换后ASCII：', resultStr);
  return resultStr.join("");
}
/*
const hexArrToCharCode = (hexArr) => {
  var resultStr = [];
  for (var i = 0; i < hexArr.length; i++) {
      let toHex = hexArr[i].toString();
      resultStr.push(String.fromCharCode(toHex));
  }
  let toStr = resultStr.join().replace(/,/g, "");
  console.log('转ASCII值后----》', toStr);
  return toStr;
}*/

 // 将字符串转换成ArrayBufer
 const string2buffer = str =>{
  //  let val = ""
  //  if(!str) return new ArrayBuffer(0)
  //  var buffer = new ArrayBuffer(str.length)
  //  let dataView = new DataView(buffer)
  //  let ind = 0
  //  for(var i = 0 , len = str.length ; i < len; i += 2){
  //    let code = parseInt(str.substr(i,2),16)
  //    dataView.setUint8(ind,code)
  //    ind++
  //   }
  //   return buffer
  var typedArray = new Uint8Array(str.match(/[\da-f]{2}/gi).map(function (h) {
    return parseInt(h, 16)
  }))
  return typedArray.buffer
 }

 const ab2hex = buffer =>{
   var hexArr = Array.prototype.map.call(
     new Uint8Array(buffer),
     function(bit){
      return ('00' + bit.toString(16)).slice(-2)
     }
   )
   hexArr.join('')
   return hexArr
 }

 //需要被调用
 const receive = () =>{
  wx.onBLECharacteristicValueChange((result) => {
    console.log('收到消息！')
    BluetoothDetail.returnValue = 
    // result.value
    // ab2hex(result.value)
    ab2hex(result.value)
    console.log("returnValue:  "+BluetoothDetail.returnValue)
    
    var return_str = hex2str(BluetoothDetail.returnValue)
    //console.log(return_str)
    app.globalData.first = return_str
    console.log(app.globalData.first)
    if(return_str == '1234123412123456'){
      wx.hideLoading({
        success : (res)=>{}
      })
      wx.showToast({
        title: '测试成功',
        icon:'success',
        duration:800
      })
    }
  })
  
}
function hex2str(hex_arr){
  var str = ""
  for(var i =0;i<hex_arr.length - 1;++i){
    str += hex_arr[i]
  }
  return str
}
function send_CMD(str){
  wx.writeBLECharacteristicValue({
    characteristicId: BluetoothDetail.writeId,
    deviceId: BluetoothDetail.deviceId,
    serviceId: BluetoothDetail.services,
    value: string2buffer(str),
    success:()=>{
      wx.onBLECharacteristicValueChange((result) => {
        BluetoothDetail.returnValue = 
        ab2hex(result.value)
        var return_str = hex2str(BluetoothDetail.returnValue)
        
        var return_ascii= hexCharCodeToStr(return_str)
        
        //console.log('接收到的消息：'+BluetoothDetail.returnValue)
        if(return_ascii.substr(0,5) == 'high:'){
          
          var highpressure = return_ascii.substr(5)
          console.log('gethigh:'+highpressure)
          util.set_high_pressure(highpressure)
          
        }
        if(return_ascii.substr(0,4) == 'low:'){
          var lowpressure = return_ascii.substr(4)
          console.log('getlow:'+lowpressure)
          util.set_low_pressure(lowpressure)
        }
        if(return_ascii == '654321'){
          console.log('low:'+util.get_low_pressure())
          console.log('high:'+util.get_high_pressure())
          console.log('测试成功！')
          //
          if(util.get_low_pressure()!='' && util.get_high_pressure()!=''){
            util.saveExprs1(util.formatTime(new Date()))
            util.saveExprs2(parseFloat(util.get_high_pressure()))
            util.saveExprs3(parseFloat(util.get_low_pressure()))
          }
          //
          wx.showToast({
            title: '测量完毕！',
            icon:'success',
            duration:800
            
          })
          wx.navigateTo({
            url: '/pages/result/result',
            })
          /*
          wx.navigateBack({
            delta: 0,
          })*/
        }
        
      })
    }
  })
}

function set_TIME(str){
  wx.showToast({
    title: '正在重置时间',
    icon:'loading',
  })
  wx.writeBLECharacteristicValue({
    characteristicId: BluetoothDetail.writeId,
    deviceId: BluetoothDetail.deviceId,
    serviceId: BluetoothDetail.services,
    value: string2buffer(str),
    success:()=>{
      var str2 = util.formatTime(new Date()).substr(10,19)//传时间字符串
      console.log(str2)
      sendMy(string2buffer(str2))
      wx.showToast({
        title: '重置时间完成',
        icon: 'none'
      })
    },
    fail(res) {
      wx.hideLoading({
        success: (res) => {},
      })
      wx.showToast({
        title: '重置时间失败',
        icon:'fails',
        duration:1000
      })
      console.log(res, '重置时间失败')
    }

  })
}

 module.exports = {
   bluetooth : bluetooth,
   send_CMD : send_CMD,
   set_TIME : set_TIME
 };