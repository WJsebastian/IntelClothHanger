const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}
const val_detail = {
  high : '',
  low : ''
}
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
const get_high_pressure = ()=>{
  return val_detail.high
}
const get_low_pressure = ()=>{
  return val_detail.low
}
const set_high_pressure = (high)=>{
  val_detail.high = high
}
const set_low_pressure = (low)=>{
  val_detail.low = low
}

var saveExprs1 = function(expr) {
  //获取存储数据的数组
  var exprs = wx.getStorageSync("measure_time") || []
  //向数组中添加新的元素
  exprs.unshift(expr)
  //将添加的元素存储到本地
  wx.setStorageSync("measure_time", exprs)
}
var saveExprs2 = function(expr) {
  var exprs = wx.getStorageSync("systolic") || []
  exprs.unshift(expr)
  wx.setStorageSync("systolic", exprs)
}
var saveExprs3 = function(expr) {
  var exprs = wx.getStorageSync("diastolic") || []
  exprs.unshift(expr)
  wx.setStorageSync("diastolic", exprs)
}

module.exports = {
  formatTime: formatTime,
  get_high_pressure : get_high_pressure,
  get_low_pressure : get_low_pressure,
  set_high_pressure : set_high_pressure,
  set_low_pressure : set_low_pressure,
  saveExprs1 : saveExprs1,
  saveExprs2 : saveExprs2,
  saveExprs3 : saveExprs3
}
